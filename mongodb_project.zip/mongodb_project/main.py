import pymongo
from connect import MongoDBHandler
from pymongo import errors
from pymongo import MongoClient
from datetime import datetime
from theatre import Theatre
from comments import Comment
from movie import Movie
from insert import Insert

def option1():
    insert.insert_comment(comment_data)

def option2():
    insert.insert_movie(movie_data)

def option3():
    insert.insert_theater(theatre_data)

def option4():
    insert.insert_user(user_data)
    
def option5():
    com = comment.find_top_10_commenter()
    print("Top 10 commenters: \n")
    for i in com:
        print(i)
        print("\n")

def option6():
    com = comment.find_top_10_movies_with_most_comments()
    print("Top 10 movies with most comments: \n")
    for i in com:
        print(i)
        print("\n")

def option7():
    year = int(input("Enter a year: "))
    com = comment.total_comments_per_month_in_year(year)
    print("Total comments per month in the year: ")
    print("\n")
    for i in com:
        print(i)
        print("\n")

def option8():
    N = int(input("Enter N: "))
    com = movie.find_top_n_movies_with_highest_rating(N)
    print("Top n movies with highest ratings: \n")
    for i in com:
        print(i)
        print("\n")

def option9():
    year = int(input("Enter a year: "))
    N = int(input("Enter N: "))
    com = movie.find_top_movies_with_highest_rating_by_year(year, N)
    print("Top movies with highest rating in a year: ")
    print("\n")
    for i in com:
        print(i)
        print("\n")

def option10():
    N = int(input("Enter N: "))
    com = movie.find_top_movies_with_highest_rating_votes(N)
    print("Top movies with highest rating and votes greater than 1000: \n")
    for i in com:
        print(i)
        print("\n")

def option11():
    pattern = input("Enter the pattern you wish to match: ")
    N = int(input("Enter N: "))
    com = movie.find_top_movies_by_pattern(pattern, N)
    print("Top movies with the provided pattern: \n")
    for i in com:
        print(i)
        print("\n")

def option12():
    N = int(input("Enter N: "))
    com = movie.find_top_directors(N)
    print("Top directors: \n")
    for i in com:
        print(i)
        print("\n")

def option13():
    year = int(input("Enter a year: "))
    N = int(input("Enter N: "))
    com = movie.find_top_directors_by_year(year, N)
    print("Top directors in the given year: \n")
    for i in com:
        print(i)
        print("\n")

def option14():
    genre = input("Enter genre: ")
    N = int(input("Enter N: "))
    com = movie.find_top_directors_by_genre(genre, N)
    print("Top directors by genre: \n")
    for i in com:
        print(i)
        print("\n")

def option15():
    N = int(input("Enter N: "))
    com = movie.find_top_actors(N)
    print("Top actors: \n")
    for i in com:
        print(i)
        print("\n")

def option16():
    year = int(input("Enter a year: "))
    N = int(input("Enter N: "))
    com = movie.find_top_actors_by_year(year, N)
    print("Top actors in a given year: \n")
    for i in com:
        print(i)
        print("\n")

def option17():
    genre = input("Enter genre: ")
    N = int(input("Enter N: "))
    com = movie.find_top_actors_for_genre(genre, N)
    print("Top actors for the genre: \n")
    for i in com:
        print(i)
        print("\n")

def option18():
    N = int(input("Enter N: "))
    com = movie.find_top_n_movies_per_genre(N)
    print("Top movies in each genre: \n")
    for i in com:
        print(i)
        print("\n")

def option19():
    com = theatre.find_top_10_cities_with_theatres()
    print("Top 10 cities with max theatres: \n")
    for i in com:
        print(i)
        print("\n")
    
def option20():
    com = theatre.find_top_10_theatres_nearby(coordinates)
    print("Top 10 theatres nearby: \n")
    for i in com:
        print(i)
        print("\n")

def main():
    while True:
        print("\nMain Menu:")
        print("1. Insert new comment")
        print("2. Insert new movie")
        print("3. Insert new theatre")
        print("4. Insert new user")
        print("5. Top 10 users with maximum comments")
        print("6. Top 10 movies with maximum comments")
        print("7. Comments each month in a year")
        print("8. Top 'n' movies with highest imdb ratings")
        print("9. Top 'n' movies with highest imdb ratings in a year")
        print("10. Top 'n' movies with highest imdb ratings with votes > 1000")
        print("11. Top 'n' movies with title matching and highest tomatoes ratings")
        print("12. Top 'n' directors with max movies")
        print("13. Top 'n' directors with max movies in a year")
        print("14. Top 'n' directors with max movies for a genre")
        print("15. Top 'n' actors with max movies")
        print("16. Top 'n' actors with max movies in a year")
        print("17. Top 'n' actors with max movies for a genre")
        print("18. Top 'n' movies with highest imdb rating in each genre")
        print("19. Top 10 cities with the max theatres")
        print("20. Top 10 theatres nearby given coordinates")

        choice = input("Enter your choice: ")

        if choice == "1":
            option1()
        elif choice == "2":
            option2()
        elif choice == "3":
            option3()
        elif choice == "4":
            option4()
        elif choice == "5":
            option5()
        elif choice == "6":
            option6()
        elif choice == "7":
            option7()
        elif choice == "8":
            option8()
        elif choice == "9":
            option9()
        elif choice == "10":
            option10()
        elif choice == "11":
            option11()
        elif choice == "12":
            option12()
        elif choice == "13":
            option13()
        elif choice == "14":
            option14()
        elif choice == "15":
            option15()
        elif choice == "16":
            option16()
        elif choice == "17":
            option17()
        elif choice == "18":
            option18()
        elif choice == "19":
            option19()
        elif choice == "20":
            option20()
        elif choice == "21":
            print("Exiting the program. Goodbye!")
            break
        else:
            print("Invalid choice. Please enter a valid option.")
        
        # Ask the user if they want to return to the main menu or exit
        while True:
            next_action = input("Do you want to return to the main menu? (y/n): ")
            if next_action.lower() == "y":
                break
            elif next_action.lower() == "n":
                print("Exiting the program. Goodbye!")
                return
            else:
                print("Invalid input. Please enter 'y' or 'n'.")


if __name__ == "__main__":
    # Reuse MongoDB connection instance
    mongo_client = MongoClient('localhost', 27017)                      

    # Define the database name and folder path
    database_name = "my_database"
    folder_path = "/Users/devjuneja/Desktop/mongodb_project"  # actual path to the folder

    # database
    db = mongo_client.my_database
    
    # creating objects of classes
    handler = MongoDBHandler(db)
    movie = Movie(db)
    comment = Comment(db)
    theatre = Theatre(db)
    insert = Insert(db)

    # Create database if it doesn't exist
    handler.create_database(mongo_client, database_name)
    collection = db["theaters"] 

    # Create 2dsphere index on the "location" field
    db.theaters.create_index([("location.geo", "2dsphere")])

    # predefined values
    coordinates = [-96.608055, 33.685692]
    comment_data = '''{"_id":{"$oid":"5a9427648b0beebeb6957a02"},"name":"Sarahh Lewis","email":"sarah_lewis@fakegmail.com","movie_id":{"$oid":"573a1390f29313caabcd471c"},"text":"Totam molestiae accusamus sed illum aut autem maiores quo. Necessitatibus dolorum sed ea rem. Nihil perferendis fugit tempore quam. Laboriosam aliquam nulla ratione explicabo unde consectetur.","date":{"$date":{"$numberLong":"354868739000"}}}'''
    user_data = '''{"_id":{"$oid":"59b99db8cfa9a34dcd7885be"},"name":"Viserys Targaryen","email":"harry_lloyd@gameofthron.es","password":"$2b$12$cpwVmU4DyuQxgwpdrVJhaudzbKOXlHRbf.tpCuHjpAqonuoyvvEG6"}'''
    theatre_data = '''{"_id":{"$oid":"59a47286cfa9a3a73e51e735"},"theaterId":{"$numberInt":"1013"},"location":{"address":{"street1":"9901 Brook Rd","city":"Glen Allen","state":"VA","zipcode":"23059"},"geo":{"type":"Point","coordinates":[{"$numberDouble":"-77.459908"},{"$numberDouble":"37.667957"}]}}}'''
    movie_data = '''{"_id":{"$oid":"573a1390f29313caabcd60e4"},"plot":"Charlie is an immigrant who endures a challenging voyage and gets into trouble as soon as he arrives in America.","genres":["Short","Comedy","Drama"],"runtime":{"$numberInt":"30"},"cast":["Charles Chaplin","Edna Purviance","Eric Campbell","Albert Austin"],"num_mflix_comments":{"$numberInt":"3"},"poster":"https://m.media-amazon.com/images/M/MV5BMTNkYWU5YjMtMjY2My00MDI4LTlmYzQtNTFkNTFjM2E1MTVlXkEyXkFqcGdeQXVyNDE5MTU2MDE@._V1_SY1000_SX677_AL_.jpg","title":"The Immigrant","fullplot":"Charlie is on his way to the USA. He wins in a card game, puts the money in Edna's bag (she and her sick mother have been robbed of everything). When he retrieves a little for himself he is accused of being a thief. Edna clears his name. Later, broke, Charlie finds a coin and goes into a restaurant. There he finds Edna, whose mother has died, and asks her to join him. When he reaches for the coin to pay for their meals it is missing (it has fallen through a hole in his pocket).","languages":["English"],"released":{"$date":{"$numberLong":"-1658102400000"}},"directors":["Charles Chaplin"],"rated":"UNRATED","awards":{"wins":{"$numberInt":"1"},"nominations":{"$numberInt":"0"},"text":"1 win."},"lastupdated":"2015-09-17 04:52:02.293000000","year":{"$numberInt":"1917"},"imdb":{"rating":{"$numberDouble":"7.8"},"votes":{"$numberInt":"4680"},"id":{"$numberInt":"8133"}},"countries":["USA"],"type":"movie","tomatoes":{"viewer":{"rating":{"$numberDouble":"4.1"},"numReviews":{"$numberInt":"636"},"meter":{"$numberInt":"90"}},"dvd":{"$date":{"$numberLong":"987033600000"}},"lastUpdated":{"$date":{"$numberLong":"1442078205000"}}}}'''
    # Insert data into MongoDB collections
    handler.insert_data_from_folder(mongo_client, database_name, folder_path)

    main()
