import pymongo
from bson import ObjectId
from pymongo import errors
from datetime import datetime

class Theatre:
    def __init__(self, db):
        self.db = db
        
    def find_top_10_cities_with_theatres(self):
        pipeline = [
            {"$group": {"_id": "$location.address.city", "total_theaters": {"$sum": 1}}},
            {"$sort": {"total_theaters": -1}},
            {"$limit": 10}
        ]
        result = self.db.theaters.aggregate(pipeline)
        return list(result)

    def find_top_10_theatres_nearby(self, coordinates):
        pipeline = [
            {"$geoNear": {
                "near": {"type": "Point", "coordinates": coordinates},
                "distanceField": "distance",  # Specify the field to store distances
                "spherical": True
            }},
            {"$project": {
                "_id": 0,
                "theaterId": 1,
                "location.address.city": 1,
                "distance": 1
            }},
            {"$limit": 10}
        ]
        try:
            result = self.db.theaters.aggregate(pipeline)
            return [{"theaterId": doc["theaterId"], "city": doc["location"]["address"]["city"], "distance": doc["distance"]} for doc in result]
        except pymongo.errors.OperationFailure as e:
            print("Error:", e)
            return []