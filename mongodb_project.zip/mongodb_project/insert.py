import bson
from bson import ObjectId
from pymongo import errors
from datetime import datetime
import json

class Insert:
    def __init__(self, db):
        self.db = db

    # new comment into the comments collection
    def insert_comment(self, comment_data):
        try:
            # Parse comment data from BSON format
            comment = json.loads(comment_data)
            bson_data = bson.json_util.loads(bson.json_util.dumps(comment))
            # Extract collection name from the comment data
            collection_name = "comments_" + str(comment['movie_id']['$oid'])
            # Get or create the collection
            collection = self.db[collection_name]
            # Insert the comment into the respective collection
            collection.insert_one(bson_data)
            print("Comment inserted successfully into collection:", collection_name)
        except Exception as e:
            print("Error inserting comment:", e)
        
    # Insert new movie into the movies collection
    def insert_movie(self, movie_data):
        try:
            # Parse movie data from BSON format
            movie = json.loads(movie_data)
            bson_data = bson.json_util.loads(bson.json_util.dumps(movie))
            # Extract collection name from the movie data
            collection_name = "movies_" + str(movie['_id']['$oid'])

            # Get or create the collection
            collection = self.db[collection_name]

            # Insert the movie into the respective collection
            collection.insert_one(bson_data)
            print("Movie inserted successfully into collection:", collection_name)
        except Exception as e:
            print("Error inserting movie:", e)
            
    # Insert new theatre into the theatres collection
    def insert_theater(self, theater_data):
        try:
            # Parse theater data from BSON format
            theater = json.loads(theater_data)
            bson_data = bson.json_util.loads(bson.json_util.dumps(theater))
            # Extract theater ID
            collection_name = "theaters_" + str(theater['_id']['$oid'])

            # Get or create the collection for theaters
            collection = self.db[collection_name]

            # Insert the theater into the collection
            collection.insert_one(bson_data)
            print("Theater inserted successfully into collection: theaters")
        except Exception as e:
            print("Error inserting theater:", e)

    # Insert new user into the users collection
    def insert_user(self, user_data):
        try:
            # Parse user data from BSON format
            user = json.loads(user_data)
            bson_data = bson.json_util.loads(bson.json_util.dumps(user))
            # Get or create the users collection
            collection_name = "users_" + str(user['_id']['$oid'])
            collection = self.db[collection_name]

            # Insert the user into the users collection
            collection.insert_one(bson_data)
            print("User inserted successfully into collection: users")
        except Exception as e:
            print("Error inserting user:", e)