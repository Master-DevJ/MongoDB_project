from bson import ObjectId
from pymongo import errors
from datetime import datetime

class Movie:
    def __init__(self, db):
        self.db = db
        
    def find_top_n_movies_with_highest_rating(self, N):
        pipeline = [
            {"$match": {"imdb.rating": {"$ne": ""}}},
            {"$sort": {"imdb.rating": -1}},
            {"$limit": N},
            {"$project": {"_id": 0, "title": 1, "rating": "$imdb.rating"}}
        ]
        cursor = self.db.movies.aggregate(pipeline)

        top_movies = [(movie["title"], movie["rating"]) for movie in cursor]
        return top_movies

    def find_top_movies_with_highest_rating_by_year(self, year, N):
        pipeline = [
            {"$match": {"year": year, "imdb.rating": {"$ne": ""}}},
            {"$sort": {"imdb.rating": -1}},
            {"$limit": N},
            {"$project": {"title": 1, "imdb.rating": 1, "_id": 0}}
        ]
        result = self.db.movies.aggregate(pipeline)
        return list(result)

    def find_top_movies_with_highest_rating_votes(self, N):
        pipeline = [
            {"$match": {"imdb.rating": {"$ne": ""}, "imdb.votes": {"$gt": 1000}}},
            {"$sort": {"imdb.rating": -1}},
            {"$limit": N},
            {"$project": {"_id": 0, "title": 1, "imdb.rating": 1, "imdb.votes": 1}}
        ]
        result = self.db.movies.aggregate(pipeline)
        return list(result)

    def find_top_movies_by_pattern(self, pattern, N):
        pipeline = [
            {"$match": {"title": {"$regex": pattern, "$options": "i"}, "tomatoes.viewer.rating": {"$ne": ""}}},
            {"$sort": {"tomatoes.viewer.rating": -1}},
            {"$limit": N},
            {"$project": {"_id": 0, "title": 1, "rating": "$tomatoes.viewer.rating"}}
        ]
        result = self.db.movies.aggregate(pipeline)
        return list(result)
    
    def find_top_directors(self, N):
        pipeline = [
            {"$unwind": "$directors"},
            {"$group": {"_id": "$directors", "total_movies": {"$sum": 1}}},
            {"$sort": {"total_movies": -1}},
            {"$limit": N},
            {"$project": {"_id": 1, "total_movies": 1}}
        ]
        result = self.db.movies.aggregate(pipeline)
        return list(result)

    def find_top_directors_by_year(self, year, N):
        pipeline = [
            {"$match": {"year": year}},
            {"$unwind": "$directors"},
            {"$group": {"_id": "$directors", "count": {"$sum": 1}}},
            {"$sort": {"count": -1}},
            {"$limit": N}
        ]
        result = self.db.movies.aggregate(pipeline)
        return list(result)

    def find_top_directors_by_genre(self, genre, N):
        pipeline = [
            {"$match": {"genres": genre}},
            {"$unwind": "$directors"},
            {"$group": {"_id": "$directors", "total_movies": {"$sum": 1}}},
            {"$sort": {"total_movies": -1}},
            {"$limit": N}
        ]
        result = self.db.movies.aggregate(pipeline)
        return list(result)

    def find_top_actors(self, N):
        pipeline = [
            {"$unwind": "$cast"},
            {"$group": {"_id": "$cast", "num_movies": {"$sum": 1}}},
            {"$sort": {"num_movies": -1}},
            {"$limit": N}
        ]
        result = self.db.movies.aggregate(pipeline)
        return list(result)

    def find_top_actors_by_year(self, year, N):
        pipeline = [
            {"$match": {"year": year}},
            {"$unwind": "$cast"},
            {"$group": {"_id": "$cast", "total_movies": {"$sum": 1}}},
            {"$sort": {"total_movies": -1}},
            {"$limit": N}
        ]
        result = self.db.movies.aggregate(pipeline)
        return list(result)

    def find_top_actors_for_genre(self, genre, N):
        pipeline = [
            {"$match": {"genres": genre}},
            {"$unwind": "$cast"},
            {"$group": {"_id": "$cast", "count": {"$sum": 1}}},
            {"$sort": {"count": -1}},
            {"$limit": N}
        ]
        result = self.db.movies.aggregate(pipeline)
        return list(result)

    def find_top_n_movies_per_genre(self, n):
        pipeline = [
            {"$unwind": "$genres"},
            {"$match": {"imdb.rating": {"$exists": True, "$ne": ""}}},
            {"$sort": {"genres": 1, "imdb.rating": -1}},
            {"$group": {"_id": "$genres", "top_movies": {"$push": {"title": "$title", "imdb_rating": "$imdb.rating"}}}},
            {"$project": {"_id": 0, "genre": "$_id", "top_movies": {"$slice": ["$top_movies", n]}}}
        ]
        result = self.db.movies.aggregate(pipeline)
        return list(result)