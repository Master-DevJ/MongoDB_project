from bson import ObjectId
from pymongo import errors
from datetime import datetime

class Comment:
    def __init__(self, db):
        self.db = db
        
    def find_top_10_commenter(self):
        pipeline = [
            {"$group": {"_id": "$email", "total_comments": {"$sum": 1}}},
            {"$sort": {"total_comments": -1}},
            {"$limit": 10}
        ]
        result = self.db.comments.aggregate(pipeline)
        return list(result)

    def find_top_10_movies_with_most_comments(self):
        pipeline = [
            {"$group": {"_id": "$movie_id", "total_comments": {"$sum": 1}}},
            {"$lookup": {
                "from": "movies",
                "localField": "_id",
                "foreignField": "_id",
                "as": "movie_info"
            }},
            {"$unwind": "$movie_info"},
            {"$project": {"movie_name": "$movie_info.title", "total_comments": 1}},
            {"$sort": {"total_comments": -1}},
            {"$limit": 10}
        ]
        result = self.db.comments.aggregate(pipeline)
        return list(result)

    def total_comments_per_month_in_year(self, year):
        pipeline = [
            {"$match": {"$expr": {"$eq": [{"$year": "$date"}, year]}}},
            {"$group": {"_id": {"$month": "$date"}, "total_comments": {"$sum": 1}}},
            {"$sort": {"_id": 1}}
        ]
        result = self.db.comments.aggregate(pipeline)
        return list(result)