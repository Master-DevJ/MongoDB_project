import pymongo
import json
from bson import ObjectId
import os
import bson.json_util
from pymongo import errors
from datetime import datetime

class MongoDBHandler:
    def __init__(self, db):
        self.db = db

    def delete_database(self, database_name):
        # Connect to MongoDB 
        client = pymongo.MongoClient("mongodb://localhost:27017/")

        # Specify the database name
        db = client[database_name]

        # Drop the database
        client.drop_database(database_name)
        print(f"Database '{database_name}' deleted successfully.")

    def create_database(self, client, database_name):
        db_list = client.list_database_names()
        if database_name not in db_list:
            print(f"Creating database '{database_name}'")
            client[database_name]

    def insert_data_from_folder(self, client, database_name, folder_path):
        db = client[database_name]

        # Iterate over files in the folder
        for filename in os.listdir(folder_path):
            if filename.endswith(".json"):
                collection_name = os.path.splitext(filename)[0]  # Extract collection name from filename
                collection = db[collection_name]
                total_documents = 0

                # Read JSON data from file
                with open(os.path.join(folder_path, filename), 'r') as file:
                    # Iterate over each line in the file
                    for line in file:
                        data = json.loads(line)
                        bson_data = bson.json_util.loads(bson.json_util.dumps(data))

                        # Insert JSON data into MongoDB collection
                        try:
                            collection.insert_one(bson_data)
                            total_documents += 1  # Increment total documents count
                        except errors.BulkWriteError as e:
                            print(f"Error inserting document into collection '{collection_name}': {e}")

                    # Print the total number of documents inserted for the collection
                print(f"Inserted {total_documents} documents into collection '{collection_name}'") 
